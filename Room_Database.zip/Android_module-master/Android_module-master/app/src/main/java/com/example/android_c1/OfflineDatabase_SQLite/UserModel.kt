package mohit.dev.a27jun2022


 class UserModel
    (
    var username: String,
    var userid: String,
    var userEmail: String,
    var  userPassword: String,
    var userMobile: String,
){}