package com.example.room_database

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ListAdapter
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.floatingactionbutton.FloatingActionButton
import mohit.dev.roomdbtops.Adapter.NoteAdapter

class MainActivity : AppCompatActivity()
{
    private lateinit var vm : NoteViewModel
    private lateinit var adapter: NoteAdapter
    override fun onCreate(savedInstanceState: Bundle?)
    {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        set_recyclerview()

        var fab = findViewById<FloatingActionButton>(R.id.button_add_note)

        fab.setOnClickListener {
            //
        }

        vm = ViewModelProviders.of(this)[NoteViewModel::class.java]

        vm.getAllNotes().observe(this, Observer {
            adapter.submitList(it)
        })


    }

    fun set_recyclerview(){
        var recyclerview = findViewById<RecyclerView>(R.id.rec_view)
        recyclerview.layoutManager = LinearLayoutManager(this)
        recyclerview.setHasFixedSize(true)


    }
}